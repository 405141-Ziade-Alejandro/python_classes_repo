from .auxiliary_methods import typewritter_printing

class Client:

    def __init__(self, nombre :str, edad :int, fecha_ingreso: str, puntaje:int):
        self.nombre = nombre
        self.edad = edad
        self.fecha_ingreso = fecha_ingreso
        self.puntaje = puntaje

    def __str__(self):
        string = f"se creo el cliente {self.nombre} con un puntaje {self.puntaje}"
        return string

    def modificar_puntaje(self, numero_puntaje: int):
        self.puntaje += numero_puntaje

    def mostrar_puntaje(self):
        typewritter_printing(f"el cliente {self.nombre} tiene un puntaje de {self.puntaje}")

    def informacion_cliente(self):
        typewritter_printing(f" el cliente {self.nombre} tiene {self.edad} y ingreso al sistema {self.fecha_ingreso}, tiene un puntaje de {self.puntaje}")