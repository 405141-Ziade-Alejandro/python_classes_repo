import time
import sys

def typewritter_printing(text, speed=0.03):
    for letter in text:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(speed)
    print() # this is to jump the line