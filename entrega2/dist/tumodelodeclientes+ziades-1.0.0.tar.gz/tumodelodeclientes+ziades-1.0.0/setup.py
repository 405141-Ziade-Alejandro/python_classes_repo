from setuptools import setup


setup(
    name='TuModeloDeClientes+Ziades',
    version='1.0.0',
    description='primera iteracion completa de la entrega de la tarea de python',
    author='alejandro ziades',
    packages=['paquete']
)