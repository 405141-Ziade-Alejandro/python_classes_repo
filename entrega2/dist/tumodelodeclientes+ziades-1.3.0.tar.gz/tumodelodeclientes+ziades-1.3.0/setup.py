from setuptools import setup


setup(
    name='TuModeloDeClientes+Ziades',
    version='1.3.0',
    description='tercera iteracion completa de la segunda entrega de la tarea de python',
    author='alejandro ziades',
    packages=['paquete']
)